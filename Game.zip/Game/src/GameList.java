import com.mycompany.assignment.Game;

/**
 * Represents a linked list of Game objects.
 */
public class GameList {

    /** The head node of the list. */
    private Node head;

    /** The length of the list. */
    private int length;

    /**
     * Represents a node in the GameList containing a Game object and a reference to the next node.
     */
    private class Node {
        /** The Game object stored in the node. */
        Game data;

        /** The next node in the list. */
        Node next;

        /**
         * Constructs a Node with a given Game object.
         *
         * @param game The Game object to be stored in the node.
         */
        Node(Game game) {
            this.data = game;
            this.next = null;
        }
    }

    /**
     * Default constructor initializes an empty GameList.
     */
    public GameList(){
        head = null;
    }

    /**
     * Copy constructor creates a deep copy of the given GameList.
     *
     * @param other The GameList to be copied.
     */
    public GameList(GameList other) {
        if (other.head == null) {
            head = null;
        } else {
            head = new Node(other.head.data);
            Node current = head;
            Node otherCurrent = other.head.next;
            while (otherCurrent != null) {
                current.next = new Node(otherCurrent.data);
                current = current.next;
                otherCurrent = otherCurrent.next;
            }
        }
        length = other.length;
    }

    /**
     * Adds a Game to the beginning of the list.
     *
     * @param g The Game object to be added.
     */
    public void add(Game g) {
        Node newNode = new Node(g);
        newNode.next = head;
        head = newNode;
        length++;
    }

    /**
     * Merges another GameList into the current list.
     *
     * @param gl The GameList to be merged.
     */
    public void add(GameList gl) {
        Node current = this.head;

        if (current == null) {
            this.head = gl.head;
        } else {
            while (current.next != null) {
                current = current.next;
            }

            Node glCurrent = gl.head;
            while (glCurrent != null) {
                current.next = new Node(glCurrent.data);
                current = current.next;
                glCurrent = glCurrent.next;
            }
        }
        length ++;
    }

    /**
     * Removes a Game with the specified title from the list.
     *
     * @param title The title of the Game to be removed.
     * @return The Game object that was removed, or null if not found.
     */
    Game remove(String title){
        Node current = head;
        Node prev = null;

        while (current != null && !current.data.getTitle().equals(title)) {
            prev = current;
            current = current.next;
        }

        if (current == null) return null;

        if (prev == null) {
            head = head.next;
        } else {
            prev.next = current.next;
        }
        length--;
        return current.data;
    }

    /**
     * Displays the titles of all games in the list.
     */
    public void show(){
        Node location = head;

        while (location != null){
            System.out.println(location.data.getTitle());
            location = location.next;
        }
    }

    /**
     * Finds the Game with the highest price in the list.
     *
     * @return The Game with the highest price, or null if the list is empty.
     */
    Game highestPriceGame(){
        if (head == null) return null;

        Node current = head;
        Game highestPrice = head.data;

        while (current != null) {
            if (current.data.getPrice() > highestPrice.getPrice()) {
                highestPrice = current.data;
            }
            current = current.next;
        }

        return highestPrice;
    }

    /**
     * Empties the GameList.
     */
    void makeEmpty(){
        head = null;
        length = 0;
    }

    /**
     * Computes and returns the length of the GameList.
     *
     * @return The total number of games in the list.
     */
    public int getLength() {
        int count = 0;
        Node temp = head;
        while (temp != null) {
            count++;
            temp = temp.next;
        }
        return count;
    }

    /**
     * Creates a deep copy of the current GameList.
     *
     * @return A new GameList object that is a deep copy of the current list.
     */
    public GameList makeCopy() {
        GameList copiedList = new GameList();
        if (this.head == null) return copiedList;

        copiedList.head = new Node(new Game(this.head.data));
        Node copiedCurrent = copiedList.head;
        Node thisCurrent = this.head.next;

        while (thisCurrent != null) {
            copiedCurrent.next = new Node(new Game(thisCurrent.data));
            copiedCurrent = copiedCurrent.next;
            thisCurrent = thisCurrent.next;
        }
        copiedList.length = this.length;

        return copiedList;
    }

    /**
     * Determines if the current GameList is equal to another object.
     *
     * @param obj The object to be compared with the current list.
     * @return true if the two objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        GameList otherList = (GameList) obj;
        if (this.length != otherList.length) return false;

        Node currentThis = this.head;
        Node currentOther = otherList.head;

        while (currentThis != null) {
            if (!currentThis.data.equals(currentOther.data)) {
                return false;
            }
            currentThis = currentThis.next;
            currentOther = currentOther.next;
        }
        return true;
    }
}
