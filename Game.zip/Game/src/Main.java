import com.mycompany.assignment.Game;

/**
 * This class demonstrates the use and interactions between the Game and GameList classes.
 * It creates and manages multiple games and game lists.
 */
public class Main {

    /**
     * The main method where the execution begins.
     * It demonstrates the creation, modification, and display of games and game lists.
     *
     * @param args command line arguments (unused in this method)
     */
    public static void main(String[] args) {
        // Creating various Game objects
        Game game1 = new Game("Subway Surfers", "Everyone", 0.00);
        Game game2 = new Game("Mortal Kombat", "Mature", 49.99);
        Game game3 = new Game("Fortnite", "Teen", 15.49);
        Game game4 = new Game("Ninjago", "E10+X ",29.99);
        Game game5 = new Game("GTA V", "Mature ",56.99);

        // Making a copy of a game
        Game game6 =game5.makeCopy();

        // Using default constructor and setters
        Game game7 = new Game();
        game7.setTitle("Mortal Kombat x");
        game7.setEsrb("Restricted");
        game7.setPrice(11.99);

        // Creating and adding games to a game list
        GameList g = new GameList();
        g.add(game1);
        g.add(game2);
        g.add(game3);
        g.show();

        // Creating another game list and adding games and other game list
        GameList f = new GameList();
        f.add(g);
        f.add(game4);
        f.add(game1);
        f.add(game1);
        f.add(game5);

        // Using copy constructor for game list
        GameList p = new GameList(g);
        p.add(game2);
        p.add(game4);

        //Showing the number of game  list 'p'
        System.out.println("\r\nThe number of games in list 'p' is: " + p.getLength());


        // Making a copy of a game list
        GameList m = f.makeCopy();

        // Displaying details of a specific game
        System.out.println("Game 2");
        System.out.println(game2.getTitle());
        System.out.println(game2.getEsrb());
        System.out.println(game2.getPrice());

        // Removing a game from a list and displaying
        Game removedGame = g.remove("Subway Surfers");
        System.out.println("\r\nThe game titled \"" + removedGame.getTitle() + "\" has been removed from the list.");
        g.show();
        //Prints the game with the highest price from list 'p' (Using title to identify).
        System.out.println("\r\nThe game with the highest price in list 'p' is: " +  p.highestPriceGame().getTitle());
        // Emptying a game list and displaying
        System.out.println("\r\nEmptying list 'g'...");
        g.makeEmpty();
        System.out.println("Displaying the contents of list 'g' after emptying:");
        g.show();
        // Comparing lists and games for equality
        System.out.println("\r\nComparing lists 'f' and 'm' for equality (Expected: true): " + (f.equals(m)));
        System.out.println("Comparing the 'game6' game object with 'game5' for equality (Expected: true): " + game6.equals(game5));
    }
}
