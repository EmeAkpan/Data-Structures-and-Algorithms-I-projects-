package com.mycompany.assignment;

/**
 * Represents a collection of Game objects.
 * Provides functionalities to manage and manipulate a list of games.
 *
 * @author mikak
 */
public class GameCollection {

    /** An array of Game objects serving as the internal storage for the game collection. */
    private Game[] games;

    /** A constant representing the default size of the game collection. */
    private  int Constructor_sSize = 10;

    /**
     * Default constructor.
     * Initializes the games array to the default size and fills it with new Game objects.
     */
    public GameCollection() {
        this.games = new Game[Constructor_sSize];
        for (int i = 0; i < Constructor_sSize; i++) {
            games[i] = new Game();
        }
    }

    /**
     * Copy constructor.
     * Creates a new GameCollection as a deep copy of the provided one.
     *
     * @param other The GameCollection to copy from.
     */
    public GameCollection(GameCollection other) {
        this.games = new Game[other.games.length];
        for (int i = 0; i < other.games.length; i++) {
            this.games[i] = other.games[i].makeCopy();
        }
    }

    /**
     * Sets a game at the specified index.
     *
     * @param index The index at which the game should be set.
     * @param g The game to be set.
     */
    public void set(int index, Game g) {
        if (index >= 0 && index < games.length) {
            games[index] = g.makeCopy();
        }
    }

    /**
     * Retrieves the game at the specified index.
     *
     * @param index The index of the game to retrieve.
     * @return A copy of the game at the specified index, or null if the index is invalid.
     */
    public Game get(int index) {
        if (index >= 0 && index < games.length) {
            return games[index].makeCopy();
        }
        return null;
    }

    /**
     * Gets the size of the games array.
     *
     * @return The size of the games array.
     */
    public int getSize() {
        return games.length;
    }

    /**
     * Creates a deep copy of the current GameCollection.
     *
     * @return A new GameCollection that is a copy of the current one.
     */
    public GameCollection makeCopy() {
        return new GameCollection(this);
    }

    /**
     * Resizes the games array to a new size.
     *
     * @param newSize The new size for the games array.
     */
    public void resize(int newSize) {
        Game[] newGames = new Game[newSize];
        for (int i = 0; i < newSize && i < games.length; i++) {
            newGames[i] = games[i];
        }
        for (int i = games.length; i < newSize; i++) {
            newGames[i] = new Game();
        }
        games = newGames;
    }

    /**
     * Compares the current GameCollection to another object.
     *
     * @param obj The object to compare to.
     * @return True if the object is a GameCollection with the same games, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        GameCollection that = (GameCollection) obj;
        if (this.games.length != that.games.length) return false;
        for (int i = 0; i < this.games.length; i++) {
            if (!this.games[i].equals(that.games[i])) return false;
        }
        return true;
    }
}
