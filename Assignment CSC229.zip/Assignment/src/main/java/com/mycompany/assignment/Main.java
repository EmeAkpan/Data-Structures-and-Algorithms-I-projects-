package com.mycompany.assignment;

/**
 * Entry point for the game and game collection demo.
 * This class demonstrates the use of the Game and GameCollection classes, showcasing their
 * constructors, methods, and functionalities.
 *
 * @author mikak
 */
public class Main {

    /**
     * The main method serving as the entry point for the application.
     *
     * @param args Command line arguments passed to the program.
     */
    public static void main(String[] args) {

        // Demonstrating the Game constructors and methods.
        Game game1 = new Game();
        Game game2 = new Game("Goose Game", "Everyone", 19.99);
        System.out.println("Game 2");
        System.out.println(game2.getTitle());
        System.out.println(game2.getEsrb());
        System.out.println(game2.getPrice());

        // Demonstrating the Game copy constructor and methods.
        Game game3 = new Game(game2);
        game1.setTitle("Mortal Kombat x");
        game1.setEsrb("Restricted");
        game1.setPrice(11.99);
        Game game4 = game1.makeCopy();
        System.out.println("\nGame 4:");
        System.out.println(game4.getTitle());
        System.out.println(game4.getEsrb());
        System.out.println(game4.getPrice());


        // Demonstrating the GameCollection constructors and methods.
        GameCollection collection1 = new GameCollection();
        GameCollection collection2 = new GameCollection();
        collection1.set(0, game1);
        collection1.set(1, game2);
        collection2.set(0, game3);
        collection2.set(1, game4);
        Game fetchedGame = collection1.get(2);
        int size = collection1.getSize();
        GameCollection copiedCollection = collection1.makeCopy();
        collection1.resize(12);
        int newSize = collection1.getSize();
        boolean areCollectionsEqual = collection1.equals(collection2);
        System.out.println("\n"+ fetchedGame);
        System.out.println(copiedCollection);
        System.out.println("Collection 1 equal to collection 2: " + areCollectionsEqual);

        // Outputting size of game.
        System.out.println("Default Size = " + size);
        System.out.println("New Size = " + newSize);


        // Checking if two Game objects are equal.
        System.out.println("\nGame 1 is equals to game 4: "+ game1.equals(game4));
        System.out.println("Game 1 is equals to game 3: "+game1.equals(game3));
        ;

    }
}
