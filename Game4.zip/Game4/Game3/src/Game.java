/**
 * The Game class represents a video game with title, ESRB rating, and price information.
 */
public class Game {
    private String title;
    private String esrb;
    private double price;

    /**
     * Default constructor that initializes a Game with empty title, ESRB, and a price of 0.0.
     */
    public Game() {
        this.title = "";
        this.esrb = "";
        this.price = 0.0;
    }

    /**
     * Parameterized constructor that creates a Game with the provided title, ESRB rating, and price.
     *
     * @param title The title of the game.
     * @param esrb  The ESRB rating of the game.
     * @param price The price of the game.
     */
    public Game(String title, String esrb, double price) {
        this.title = title;
        this.esrb = esrb;
        this.price = price;
    }

    /**
     * Copy constructor that creates a deep copy of the provided Game instance.
     *
     * @param other The Game to be copied.
     */
    public Game(Game other) {
        this.title = other.title;
        this.esrb = other.esrb;
        this.price = other.price;
    }

    /**
     * Getter method to retrieve the title of the game.
     *
     * @return The title of the game.
     */
    public String getTitle() {
        return this.title;
    }

    /**
     * Setter method to set the title of the game.
     *
     * @param title The new title for the game.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Getter method to retrieve the ESRB rating of the game.
     *
     * @return The ESRB rating of the game.
     */
    public String getEsrb() {
        return this.esrb;
    }

    /**
     * Setter method to set the ESRB rating of the game.
     *
     * @param esrb The new ESRB rating for the game.
     */
    public void setEsrb(String esrb) {
        this.esrb = esrb;
    }

    /**
     * Getter method to retrieve the price of the game.
     *
     * @return The price of the game.
     */
    public double getPrice() {
        return this.price;
    }

    /**
     * Setter method to set the price of the game.
     *
     * @param price The new price for the game.
     */
    public void setPrice(double price) {
        this.price = price;
    }

    /**
     * Creates and returns a deep copy of the current Game instance.
     *
     * @return A new Game instance that is a deep copy of the current one.
     */
    public Game makeCopy() {
        return new Game(this.title, this.esrb, this.price);
    }

    /**
     * Overrides the default equals method to compare two Game instances for equality.
     * Compares the title, ESRB rating, and price to determine equality.
     *
     * @param obj The object to compare with this Game.
     * @return true if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        } else if (obj != null && this.getClass() == obj.getClass()) {
            Game game = (Game) obj;
            return Double.compare(game.price, this.price) == 0 && this.title.equals(game.title) && this.esrb.equals(game.esrb);
        } else {
            return false;
        }
    }
}
