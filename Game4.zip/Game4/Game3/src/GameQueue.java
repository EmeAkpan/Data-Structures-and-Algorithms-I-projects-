/**
 * The GameQueue class represents a queue of Game objects using a linked list.
 */
public class GameQueue {
    private Node front;
    private Node rear;
    private int size;

    /**
     * Node class for linked representation.
     */
    private static class Node {
        Game data;
        Node next;

        /**
         * Node constructor that creates a new node with the provided Game data.
         * Performs a deep copy of the Game data.
         *
         * @param data The Game data to be stored in the node.
         */
        Node(Game data) {
            this.data = data.makeCopy();
            next = null;
        }
    }

    /**
     * Default constructor that initializes a new GameQueue with empty front, rear, and size.
     */
    public GameQueue() {
        front = rear = null;
        size = 0;
    }

    /**
     * Copy constructor that creates a deep copy of the provided GameQueue instance.
     *
     * @param other The GameQueue to be copied.
     */
    public GameQueue(GameQueue other) {
        this.size = other.size;
        if (other.front != null) {
            this.front = new Node(other.front.data);
            Node temp = other.front;
            Node current = this.front;

            while (temp.next != null) {
                current.next = new Node(temp.next.data);
                temp = temp.next;
                current = current.next;
            }

            this.rear = current;
        }
    }

    /**
     * Adds a new game to the end of the queue.
     *
     * @param g The Game to be added to the queue.
     */
    public void enqueue(Game g) {
        Node newNode = new Node(g);
        if (rear == null) {
            front = newNode;
            rear = newNode;
        } else {
            rear.next = newNode;
            rear = newNode;
        }
        size++;
    }

    /**
     * Removes and returns the front element of the queue.
     * Handles the case when the queue is empty by returning null.
     *
     * @return The front Game in the queue, or null if the queue is empty.
     */
    public Game dequeue() {
        if (front != null) {
            Game data = front.data;
            front = front.next;
            if (front == null) {
                rear = null;
            }
            size--;
            return data;
        }
        return null;
    }

    /**
     * Clears the queue by setting front, rear, and size to null or 0.
     */
    public void makeEmpty() {
        front = null;
        rear = null;
        size = 0;
    }

    /**
     * Returns the current number of elements in the queue (the size).
     *
     * @return The number of elements in the queue.
     */
    public int getLength() {
        return size;
    }

    /**
     * Creates and returns a deep copy of the current GameQueue instance.
     *
     * @return A new GameQueue instance that is a deep copy of the current one.
     */
    public GameQueue makeCopy() {
        return new GameQueue(this);
    }

    /**
     * Overrides the default equals method to compare two GameQueue instances for equality.
     * Compares the data in corresponding nodes and the sizes to determine equality.
     *
     * @param obj The object to compare with this GameQueue.
     * @return true if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        GameQueue other = (GameQueue) obj;
        Node temp1 = this.front;
        Node temp2 = other.front;
        while (temp1 != null && temp2 != null) {
            if (!temp1.data.equals(temp2.data)) {
                return false;
            }
            temp1 = temp1.next;
            temp2 = temp2.next;
        }
        return temp1 == null && temp2 == null;
    }
}
