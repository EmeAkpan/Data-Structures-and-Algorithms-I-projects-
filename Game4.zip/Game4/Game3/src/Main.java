public class Main {

    public static void main(String[] args) {

        // Creating instances of the Game class
        Game game1 = new Game("GTA", "17+", 59.99);
        Game game2 = new Game("Mortal Kombat", "13+", 39.99);
        Game game3 = new Game("Fortnite", "Everyone", 19.99);

        // Testing Game class methods
        System.out.println("=== Testing Game Class ===");
        System.out.println("Game 1: " + game1.getTitle() + ", " + game1.getEsrb() + ", $" + game1.getPrice());
        System.out.println("Game 2: " + game2.getTitle() + ", " + game2.getEsrb() + ", $" + game2.getPrice());
        System.out.println("Game 3: " + game3.getTitle() + ", " + game3.getEsrb() + ", $" + game3.getPrice());

        // Creating instances of the GameQueue class
        GameQueue queue1 = new GameQueue();
        queue1.enqueue(game1);
        queue1.enqueue(game2);

        // Testing GameQueue class methods
        System.out.println("\n=== Testing GameQueue Class ===");
        System.out.println("Queue 1 Length: " + queue1.getLength());

        // Creating a deep copy of GameQueue
        GameQueue queue2 = queue1.makeCopy();
        System.out.println("Queue 2 Length (Copy): " + queue2.getLength());

        // Dequeue and display
        Game dequeuedGame = queue1.dequeue();
        System.out.println("Dequeued Game: " + (dequeuedGame != null ? dequeuedGame.getTitle() : "Queue is empty"));

        // Creating instances of the GameStack class
        GameStack stack1 = new GameStack();
        stack1.push(game1);
        stack1.push(game2);


        // Testing GameStack class methods
        System.out.println("\n=== Testing GameStack Class ===");
        System.out.println("Stack 1 Length: " + stack1.getLength());

        // Creating a deep copy of GameStack
        GameStack stack2 = stack1.makeCopy();
        System.out.println("Stack 2 Length (Copy): " + stack2.getLength());

        //Showing instance of Make Empty method(stack)
        GameStack stack3=new GameStack();
        stack3.push(game1);
        stack3.push(game3);
        stack3.push(game1);
        stack3.push(game2);
        System.out.println("Stack 3 length: "+stack3.getLength());
        stack3.makeEmpty();
        System.out.println("Stack 3 length(after make empty usage): "+stack3.getLength());

        //Showing instance of Make Empty method(linked queue)
        GameQueue queue3= new GameQueue();
        queue3.enqueue(game2);
        queue3.enqueue(game2);
        queue3.enqueue(game1);
        queue3.enqueue(game3);
        queue3.enqueue(game1);
        System.out.println("Queue 3 length: "+queue3.getLength());
        queue3.makeEmpty();
        System.out.println("Queue 3 length(after make empty usage): "+queue3.getLength());


        // Pop and display
        stack1.pop();
        System.out.println("Top Game after Pop: " + (stack1.top() != null ? stack1.top().getTitle() : "Stack is empty"));
    }
}
