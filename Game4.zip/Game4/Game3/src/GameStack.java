import java.util.Arrays;

// GameStack Class
public class GameStack {

    // Game class definition goes here

    private Game[] stack;
    private int top;

    // Default constructor
    public GameStack() {
        stack = new Game[10];
        top = -1;
    }

    // Copy constructor (Deep Copy)
    public GameStack(GameStack other) {
        this.stack = Arrays.copyOf(other.stack, other.stack.length);
        this.top = other.top;
    }

    // Adds the Game instance to the front of the list.
    public void push(Game g) {
        if (top == stack.length - 1) {
            // Stack is full, resize it
            stack = Arrays.copyOf(stack, stack.length * 2);
        }
        stack[++top] = g.makeCopy();
    }

    // Removes the top element from the stack (does not return anything).
    public void pop() {
        if (top >= 0) {
            top--;
        }
    }

    // Returns the game at the top of the stack.
    public Game top() {
        if (top >= 0) {
            return stack[top];
        }
        return null;
    }

    // Clears the stack.
    public void makeEmpty() {
        top = -1;
    }

    // Returns the number of games being stored in the stack.
    public int getLength() {
        return top + 1;
    }

    // Write a makeCopy method (should be a DEEP COPY of the current instance).
    public GameStack makeCopy() {
        return new GameStack(this);
    }

    // Implement an equals override.
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        GameStack otherStack = (GameStack) obj;
        return Arrays.equals(stack, otherStack.stack) && top == otherStack.top;
    }

}
