/**
 * The GameBinarySearchTree class represents a binary search tree of Game objects.
 * Each node in the tree contains a Game object, and the tree is organized based on the title of the games.
 */
public class GameBinarySearchTree {

    /**
     * Represents a node in the binary search tree.
     */
    private class TreeNode {
        Game data;
        TreeNode left;
        TreeNode right;

        /**
         * Constructs a new TreeNode with the provided Game data.
         *
         * @param data The Game data to be stored in the node.
         */
        public TreeNode(Game data) {
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    private TreeNode root; // The root of the binary search tree
    private int length;    // The number of games in the tree

    /**
     * Default constructor that initializes an empty GameBinarySearchTree.
     */
    public GameBinarySearchTree() {
        this.root = null;
        this.length = 0;
    }

    /**
     * Copy constructor that creates a deep copy of the provided GameBinarySearchTree instance.
     *
     * @param other The GameBinarySearchTree to be copied.
     */
    public GameBinarySearchTree(GameBinarySearchTree other) {
        this.root = deepCopy(other.root);
        this.length = other.length;
    }

    private TreeNode deepCopy(TreeNode node) {
        if (node == null) {
            return null;
        }
        TreeNode newNode = new TreeNode(node.data.makeCopy());
        newNode.left = deepCopy(node.left);
        newNode.right = deepCopy(node.right);
        return newNode;
    }

    /**
     * Clears all items from the tree.
     */
    public void clear() {
        root = null;
        length = 0;
    }

    /**
     * Returns the number of games being stored in the tree.
     *
     * @return The number of games in the tree.
     */
    public int getLength() {
        return length;
    }

    /**
     * Adds a Game object to the binary search tree.
     *
     * @param g The Game to be added to the tree.
     */
    public void add(Game g) {
        root = insert(root, g);
        length++;
    }

    private TreeNode insert(TreeNode node, Game g) {
        if (node == null) {
            return new TreeNode(g);
        }

        int compareResult = g.getTitle().compareTo(node.data.getTitle());

        if (compareResult < 0) {
            node.left = insert(node.left, g);
        } else if (compareResult > 0) {
            node.right = insert(node.right, g);
        } else {
            // Duplicate key, do not insert
        }

        return node;
    }

    /**
     * Print all game item names in the tree using a preorder traversal.
     */
    public void preorder() {
        preorderTraversal(root);
    }

    private void preorderTraversal(TreeNode node) {
        if (node != null) {
            System.out.println(node.data.getTitle());
            preorderTraversal(node.left);
            preorderTraversal(node.right);
        }
    }

    /**
     * Print all game item names in the tree using an inorder traversal.
     */
    public void inorder() {
        inorderTraversal(root);
    }

    private void inorderTraversal(TreeNode node) {
        if (node != null) {
            inorderTraversal(node.left);
            System.out.println(node.data.getTitle());
            inorderTraversal(node.right);
        }
    }

    /**
     * Print all game item names in the tree using a postorder traversal.
     */
    public void postorder() {
        postorderTraversal(root);
    }

    private void postorderTraversal(TreeNode node) {
        if (node != null) {
            postorderTraversal(node.left);
            postorderTraversal(node.right);
            System.out.println(node.data.getTitle());
        }
    }

    /**
     * Get the game associated with the given item name.
     *
     * @param title The title of the game to search for.
     * @return The Game object associated with the given title, or null if not found.
     */
    public Game getGame(String title) {
        return findGame(root, title);
    }

    private Game findGame(TreeNode node, String title) {
        if (node == null) {
            return null;
        }

        int compareResult = title.compareTo(node.data.getTitle());

        if (compareResult < 0) {
            return findGame(node.left, title);
        } else if (compareResult > 0) {
            return findGame(node.right, title);
        } else {
            return node.data;
        }
    }

    /**
     * Returns the sum of all game prices in the tree using recursion.
     *
     * @return The total price of all games in the tree.
     */
    public double totalPriceUsingRecursion() {
        return calculateTotalPrice(root);
    }

    private double calculateTotalPrice(TreeNode node) {
        if (node == null) {
            return 0.0;
        }

        return node.data.getPrice() + calculateTotalPrice(node.left) + calculateTotalPrice(node.right);
    }

    /**
     * Creates and returns a deep copy of the current GameBinarySearchTree instance.
     *
     * @return A new GameBinarySearchTree instance that is a deep copy of the current one.
     */
    public GameBinarySearchTree makeCopy() {
        return new GameBinarySearchTree(this);
    }

    /**
     * Overrides the equals method to compare two GameBinarySearchTree instances for equality.
     *
     * @param obj The object to compare with this GameBinarySearchTree.
     * @return true if the objects are equal, false otherwise.
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        GameBinarySearchTree other = (GameBinarySearchTree) obj;
        return equals(root, other.root);
    }

    private boolean equals(TreeNode node1, TreeNode node2) {
        if (node1 == null && node2 == null) {
            return true;
        }

        if (node1 != null && node2 != null) {
            return node1.data.equals(node2.data) && equals(node1.left, node2.left) && equals(node1.right, node2.right);
        }

        return false;
    }
}
