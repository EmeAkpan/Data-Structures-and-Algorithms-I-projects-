/**
 * The Main class serves as the entry point for the program and contains the main method
 * to test the functionality of the Game and GameBinarySearchTree classes.
 */
public class Main {

    /**
     * The main method creates instances of Game and GameBinarySearchTree classes,
     * tests their methods, and displays the results.
     *
     * @param args The command-line arguments (not used in this program).
     */
    public static void main(String[] args) {
        // Test Game class
        Game game1 = new Game("GTA", "Mature", 19.99);
        Game game2 = new Game("Fortnite", "Everyone", 29.99);
        Game game3 = new Game("Mortal Kombat", "rated r", 39.99);

        // Test GameBinarySearchTree class
        GameBinarySearchTree t1 = new GameBinarySearchTree();

        // Test add method
        t1.add(game2);
        t1.add(game1);
        t1.add(game3);

        // Test getLength method
        System.out.println("Number of games in the tree: " + t1.getLength());

        // Test preorder method
        System.out.println("Preorder traversal:");
        t1.preorder();

        // Test inorder method
        System.out.println("Inorder traversal:");
        t1.inorder();

        // Test postorder method
        System.out.println("Postorder traversal:");
        t1.postorder();

        // Test getGame method
        String searchTitle = "GTA"; // Update searchTitle to an existing title for proper testing
        Game foundGame = t1.getGame(searchTitle);
        if (foundGame != null) {
            System.out.println("Game found for title " + searchTitle + ": " + foundGame.getTitle());
        } else {
            System.out.println("Game not found for title " + searchTitle);
        }

        // Test totalPriceUsingRecursion method
        double totalPrice = t1.totalPriceUsingRecursion();
        System.out.println("Total price of all games in the tree: $" + totalPrice);

        // Test makeCopy method
        GameBinarySearchTree copyTree = t1.makeCopy();
        System.out.println("Copy of the tree:");
        copyTree.inorder();

        //Test clear method
        GameBinarySearchTree t2 = new GameBinarySearchTree();
        t2.add(game2);
        t2.add(game1);
        t2.add(game2);
        t2.add(game1);
        t2.add(game3);
        System.out.println("Before Clear " + t2.getLength());
        t2.clear();
        System.out.println("After " + t2.getLength());

        // Test equals method
        boolean areEqual = t1.equals(copyTree);
        System.out.println("Are the original tree and the copy equal? " + areEqual);
    }
}
