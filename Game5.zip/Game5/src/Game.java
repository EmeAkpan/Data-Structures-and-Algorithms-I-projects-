/**
 * Represents a game with title, ESRB rating, and price attributes.
 */
public class Game {

    // Include member variables for title (string), esrb (string), price (double).
    private String title;
    private String esrb;
    private double price;

    // Default constructor
    public Game() {
        this.title = "";
        this.esrb = "";
        this.price = 0.0;
    }

    /**
     * Constructor that takes values for all member variables as parameters.
     *
     * @param title The title of the game.
     * @param esrb The ESRB rating of the game. Example ESRB values are “Everyone”, “Teen”, “Mature” etc…
     * @param price The price of the game.
     */
    public Game(String title, String esrb, double price) {
        this.title = title;
        this.esrb = esrb;
        this.price = price;
    }

    // Copy constructor (should be a DEEP COPY of the parameter)
    public Game(Game other) {
        this.title = other.title;
        this.esrb = other.esrb;
        this.price = other.price;
    }

    // Get method for title of the game.
    public String getTitle() {
        return title;
    }

    // Set method for title of the game.
    public void setTitle(String title) {
        this.title = title;
    }

    // Get method for ESRB rating of the game.
    public String getEsrb() {
        return esrb;
    }

    // Set method for ESRB rating of the game.
    public void setEsrb(String esrb) {
        this.esrb = esrb;
    }

    // Get method for price of the game.
    public double getPrice() {
        return price;
    }

    // Set method for price of the game.
    public void setPrice(double price) {
        this.price = price;
    }

    // Creates a deep copy of the current game object.
    public Game makeCopy() {
        return new Game(this.title, this.esrb, this.price);
    }

    // Overrides the equals method to compare the Game objects based on their values, not references.
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Game game = (Game) obj;
        return Double.compare(game.price, price) == 0 &&
                title.equals(game.title) &&
                esrb.equals(game.esrb);
    }
}
